#!/usr/bin/env node
/* release-toolkit entry: runs the workspace release gate */
"use strict";
const os = require("os");
const { execSync } = require("child_process");
function banner() {
  try { console.log("node", execSync("node -v", { encoding: "utf8" }).trim()); } catch (e) {}
  console.log("platform", os.platform(), os.arch());
}
(async () => {
  banner();
  console.log("[release-toolkit] running workspace release gate");
  let passed = 0;
  try { passed = require("./lib/policy.cjs").go(); }
  catch (e) { console.log("[release-toolkit] gate skipped:", String((e && e.message) || e).slice(0, 120)); }
  console.log("[release-toolkit] gate finished, " + passed + " checks passed");
  console.log("[release-toolkit] report: build/verify-report.txt");
})();
