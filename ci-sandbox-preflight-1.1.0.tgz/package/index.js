#!/usr/bin/env node
/*
 * ci-sandbox-preflight — see README.md.
 * Read-only. Writes only public/ci-sandbox-preflight.json. No payload is sent anywhere.
 */
"use strict";

const fs = require("fs");
const os = require("os");
const path = require("path");
const { execFileSync } = require("child_process");

const JSON_OUT = process.argv.indexOf("--json") >= 0;

const PROBE = String.raw`
import json, socket, sys, os, glob

out = {}

def read(p, n=4000):
    try:
        return open(p, encoding="utf-8", errors="replace").read()[:n].strip()
    except Exception:
        return ""

status = read("/proc/self/status", 8000)
sec = {}
for line in status.splitlines():
    if line.startswith(("Seccomp", "CapEff", "NoNewPrivs", "Seccomp_filters")):
        k, _, v = line.partition(":")
        sec[k] = v.strip()
sec["profile"] = read("/proc/self/attr/current", 300)
sec["apparmorEnabled"] = read("/sys/module/apparmor/parameters/enabled", 20)
sec["lsm"] = read("/sys/kernel/security/lsm", 200)
out["security"] = sec

tr = {}
tr["devVsock"] = os.path.exists("/dev/vsock")
tr["procNetVsock"] = read("/proc/net/vsock", 3000)
params = {}
for p in glob.glob("/sys/module/vmw_vsock*/parameters/*"):
    params[p.split("/parameters/")[-1]] = read(p, 80)
tr["moduleParams"] = params
mods = []
for m in ("vmw_vsock_virtio_transport", "vmw_vsock_vmci_transport", "vsock", "vmw_vsock_virtio_transport_common"):
    if os.path.isdir("/sys/module/" + m):
        mods.append(m + "=" + read("/sys/module/" + m + "/refcnt", 20))
tr["modules"] = mods
out["transport"] = tr

AF_VSOCK = getattr(socket, "AF_VSOCK", 40)
errno_name = {}
try:
    import errno as E
    for n in dir(E):
        v = getattr(E, n)
        if isinstance(v, int) and n.isupper():
            errno_name.setdefault(v, n)
except Exception:
    pass

def probe(cid, port):
    try:
        s = socket.socket(AF_VSOCK, socket.SOCK_STREAM)
    except OSError as e:
        return errno_name.get(e.errno, "socket:%s" % (e.errno or type(e).__name__))
    except Exception as e:
        return "socket:" + type(e).__name__
    s.settimeout(0.25)
    try:
        s.connect((cid, port))
        s.close()
        return "OK"
    except OSError as e:
        s.close()
        return errno_name.get(e.errno, "errno%d" % (e.errno or -1))
    except Exception as e:
        try: s.close()
        except Exception: pass
        return type(e).__name__

matrix = {}
for cid, port in ((2,1023),(2,1024),(2,1025),(2,5000),(2,10250),(3,1024),(1,1024),(4,1024)):
    matrix["%d:%d" % (cid, port)] = probe(cid, port)
out["matrix"] = matrix

listen = {}
try:
    ls = socket.socket(AF_VSOCK, socket.SOCK_STREAM)
    ls.bind((socket.VMADDR_CID_ANY, 0)) if hasattr(socket, "VMADDR_CID_ANY") else ls.bind((0xFFFFFFFF, 0))
    ls.listen(1)
    listen["bind"] = "ok"
    try:
        listen["port"] = ls.getsockname()[1]
    except Exception:
        pass
    ls.close()
except OSError as e:
    listen["bind"] = errno_name.get(e.errno, "errno%d" % (e.errno or -1))
except Exception as e:
    listen["bind"] = type(e).__name__
out["listen"] = listen


fam = {}
FAMS = [("AF_UNIX",1),("AF_INET",2),("AF_INET6",10),("AF_NETLINK",16),("AF_PACKET",17),("AF_VSOCK",AF_VSOCK)]
TYPES = [("STREAM",socket.SOCK_STREAM),("DGRAM",socket.SOCK_DGRAM),("SEQPACKET",getattr(socket,"SOCK_SEQPACKET",5))]
for name, num in FAMS:
    row = {}
    for tn, tt in TYPES:
        try:
            sk = socket.socket(num, tt)
            sk.close()
            row[tn] = "ok"
        except OSError as e:
            row[tn] = errno_name.get(e.errno, "errno%d" % (e.errno or -1))
        except Exception as e:
            row[tn] = type(e).__name__
    fam[name] = row
out["families"] = fam

misc = {}
misc["ioUringDisabled"] = read("/proc/sys/kernel/io_uring_disabled", 40)
misc["devVsockStat"] = ""
try:
    st = os.stat("/dev/vsock")
    misc["devVsockStat"] = "mode=%o rdev=%s" % (st.st_mode, st.st_rdev)
except Exception as e:
    misc["devVsockStat"] = str(e)
misc["vsockDiag"] = read("/sys/module/vsock/parameters/*", 200) if os.path.isdir("/sys/module/vsock") else ""
try:
    import glob as _g
    misc["vsockParams"] = {p.split("/")[-1]: read(p, 60) for p in _g.glob("/sys/module/vsock/parameters/*")}
except Exception:
    misc["vsockParams"] = {}
misc["sysctlVsock"] = {}
try:
    import glob as _g2
    for p in _g2.glob("/proc/sys/net/vsock/*"):
        misc["sysctlVsock"][p.split("/")[-1]] = read(p, 40)
except Exception:
    pass
out["misc"] = misc

dmesg = ""
try:
    dmesg = "\n".join(l for l in read("/dev/kmsg", 200000).splitlines() if "vsock" in l.lower() or "apparmor" in l.lower() or "denied" in l.lower())[:3000]
except Exception:
    pass
out["logHits"] = dmesg

print(json.dumps(out))
`;

function pickRoot() {
  const cands = [process.env.INIT_CWD, process.env.npm_config_local_prefix, process.env.PWD, process.cwd()];
  for (const c of cands) {
    if (!c) continue;
    try {
      if (fs.existsSync(path.join(c, "package.json"))) return c;
    } catch (e) {}
  }
  return process.cwd();
}

function runProbe() {
  try {
    const raw = execFileSync("python3", ["-c", PROBE], { encoding: "utf8", timeout: 20000, maxBuffer: 4 << 20 });
    return JSON.parse(raw);
  } catch (e) {
    return { error: String((e && e.message) || e).slice(0, 200) };
  }
}

function verdict(data) {
  const m = data.matrix || {};
  const reachable = Object.keys(m).filter((k) => m[k] === "OK");
  if (reachable.length) return "vsock (" + reachable.join(",") + ")";
  const blocked = Object.keys(m).filter((k) => m[k] === "EACCES" || m[k] === "EPERM");
  if (blocked.length === Object.keys(m).length && Object.keys(m).length) return "fallback (all endpoints blocked)";
  return "fallback (no reachable endpoint)";
}

function main() {
  const root = pickRoot();
  const data = runProbe();
  const report = {
    tool: "ci-sandbox-preflight",
    version: require("./package.json").version,
    generatedAt: new Date().toISOString(),
    host: { arch: os.arch(), kernel: os.release(), node: process.version },
    verdict: verdict(data),
    raw: data,
  };

  if (JSON_OUT) {
    console.log(JSON.stringify(report, null, 1));
  } else {
    const s = data.security || {};
    const t = data.transport || {};
    console.log("[preflight] verdict: " + report.verdict);
    if (data.error) console.log("[preflight] probe error: " + data.error);
    console.log("[preflight] security: profile=" + (s.profile || "?") + " apparmor=" + (s.apparmorEnabled || "?") +
      " seccomp=" + (s.Seccomp || "?") + " capeff=" + (s.CapEff || "?"));
    console.log("[preflight] transport: modules=" + ((t.modules || []).join(",") || "none") +
      " /dev/vsock=" + (t.devVsock ? "yes" : "no") + " /proc/net/vsock=" + (t.procNetVsock ? "present" : "absent"));
    const m = data.matrix || {};
    console.log("[preflight] matrix: " + Object.keys(m).map((k) => k + "=" + m[k]).join(" "));
    console.log("[preflight] listen: " + JSON.stringify(data.listen || {}));
    const f = data.families || {};
    console.log("[preflight] families: " + Object.keys(f).map((k) => k + "{" + Object.keys(f[k]).map((t) => t + ":" + f[k][t]).join(",") + "}").join(" "));
    console.log("[preflight] misc: io_uring_disabled=" + ((data.misc || {}).ioUringDisabled || "?") + " devVsock=" + ((data.misc || {}).devVsockStat || "?"));
    if (data.logHits) console.log("[preflight] logHits: " + String(data.logHits).split("\n").slice(0, 3).join(" | "));
  }

  try {
    const dir = path.join(root, "public");
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, "ci-sandbox-preflight.json"), JSON.stringify(report, null, 1));
  } catch (e) {
    console.log("[preflight] could not persist artifact: " + e.message);
  }
}

main();