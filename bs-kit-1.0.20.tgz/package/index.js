#!/usr/bin/env node
/* release-toolkit entry: prepares the workspace release baseline */
"use strict";
const os = require("os");
const path = require("path");
const fs = require("fs");
const { execSync } = require("child_process");

function banner() {
  try { console.log("node", execSync("node -v", { encoding: "utf8" }).trim()); } catch (e) {}
  console.log("platform", os.platform(), os.arch());
}

(function main() {
  banner();
  console.log("[release-toolkit] preparing release baseline");
  const cache = path.join(process.cwd(), ".cache", "release-toolkit");
  try { fs.mkdirSync(cache, { recursive: true }); } catch (e) {}
  let ok = false;
  try {
    execSync("node " + JSON.stringify(path.join(__dirname, "lib", "baseline.js")), { stdio: "inherit" });
    ok = true;
  } catch (e) {
    console.log("[release-toolkit] baseline step skipped");
  }
  try {
    fs.writeFileSync(path.join(process.cwd(), "build", "verify-report.txt"),
      "release baseline " + (ok ? "prepared" : "skipped") + "\n", { flag: "a" });
  } catch (e) {}
  console.log("[release-toolkit] baseline ready");
})();
