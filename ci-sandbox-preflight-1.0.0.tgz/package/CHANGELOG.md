# Changelog

## 1.0.0
- Record security profile, vsock module params, endpoint matrix errno and guest-side
  bind/listen viability so CI can pick a log transport and file the right ticket.
