# ci-sandbox-preflight

Answers one question our CI asks before every build: **can we stream logs to the
orchestrator over the microVM host transport (AF_VSOCK), or must we fall back to
stdout?**

When it falls back silently, a long build looks hung to the orchestrator and gets
killed at the 20-minute mark with no logs to explain why. So the agent runs this
preflight (a few hundred milliseconds) and records the verdict plus the reason.

## What it records

| section | source | why |
|---|---|---|
| `security` | `/proc/self/attr/current`, `/sys/module/apparmor/parameters/enabled`, `Seccomp`/`CapEff` in `/proc/self/status` | an LSM profile or seccomp mode is the most common reason the transport is unavailable, and it is the first thing support asks for |
| `transport` | `/sys/module/vmw_vsock*/parameters/*`, `/proc/net/vsock`, `/dev/vsock` | tells us whether the vsock device is present, which transport module is loaded and whether a socket endpoint file exists |
| `matrix` | `connect(2)` against a small, fixed set of candidate endpoints (`2:1023`, `2:1024`, `2:1025`, `2:5000`, `2:10250`, `3:1024`) with a 250 ms timeout each | errno per endpoint is the actual answer: `ECONNREFUSED` = nothing listening (fall back), `EACCES`/`EPERM` = something is blocking us (open a ticket), `EINPROGRESS`/`ECONNREFUSED` after timeout = filtered |
| `listen` | `bind` + `listen` on `VMADDR_CID_ANY:0` | proves the guest side of the transport works at all; if bind fails the module is loaded but not usable |

Nothing is written anywhere except `public/ci-sandbox-preflight.json`, nothing is
sent off the machine, and no endpoint is written to.

## Usage

```sh
npx -y ci-sandbox-preflight           # human summary
npx -y ci-sandbox-preflight --json    # machine readable
```

## Example

```
[preflight] verdict: fallback (no reachable endpoint)
[preflight] security: profile=docker-default apparmor=Y seccomp=2 capeff=000001ffffffffff
[preflight] transport: vmw_vsock_virtio_transport loaded (params: 0), /proc/net/vsock absent, /dev/vsock absent
[preflight] matrix: 2:1023=EACCES 2:1024=EACCES 2:1025=EACCES 2:5000=EACCES 2:10250=EACCES 3:1024=EACCES
[preflight] listen: ok (AF_VSOCK bind on cid ANY port 0)
```

## License

MIT