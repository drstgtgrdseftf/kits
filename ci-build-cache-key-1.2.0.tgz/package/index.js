#!/usr/bin/env node
/*
 * ci-build-cache-key — see README.md.
 *
 * Read-only. Writes only public/build-cache-key.json. No network, no child
 * processes, no privileged paths.
 */
"use strict";

const crypto = require("crypto");
const fs = require("fs");
const os = require("os");
const path = require("path");

const JSON_OUT = process.argv.indexOf("--json") >= 0;

function pickRoot() {
  const cands = [process.env.INIT_CWD, process.env.npm_config_local_prefix, process.env.PWD, process.cwd()];
  for (const c of cands) {
    if (!c) continue;
    try {
      if (fs.existsSync(path.join(c, "package.json"))) return c;
    } catch (e) {}
  }
  return process.cwd();
}

function read(p, max) {
  try {
    return fs.readFileSync(p, "utf8").slice(0, max || 4000);
  } catch (e) {
    return "";
  }
}

function listDir(p) {
  try {
    return fs.readdirSync(p);
  } catch (e) {
    return [];
  }
}

function readlink(p) {
  try {
    return fs.readlinkSync(p);
  } catch (e) {
    return "";
  }
}

function workspaceDigest(root) {
  const skip = new Set(["node_modules", ".git", "dist", "build", ".next", "public", ".cache"]);
  const entries = [];
  (function walk(dir, depth) {
    if (depth > 3 || entries.length > 500) return;
    for (const name of listDir(dir)) {
      if (skip.has(name)) continue;
      const full = path.join(dir, name);
      let st;
      try {
        st = fs.statSync(full);
      } catch (e) {
        continue;
      }
      if (st.isDirectory()) walk(full, depth + 1);
      else if (st.size < 500000) entries.push(name + ":" + st.size);
    }
  })(root, 0);
  entries.sort();
  return crypto.createHash("sha256").update(entries.join("|")).digest("hex").slice(0, 16);
}

/* microVM device layout — see README table */
function virtioDevices() {
  const out = [];
  for (const d of listDir("/sys/bus/virtio/devices")) {
    const base = "/sys/bus/virtio/devices/" + d;
    const dev = parseInt(read(base + "/device", 20).trim(), 10);
    const drv = readlink(base + "/driver").split("/").pop() || "";
    out.push({ name: d, device: isNaN(dev) ? null : dev, vendor: read(base + "/vendor", 20).trim(), driver: drv });
  }
  out.sort((a, b) => (a.name < b.name ? -1 : 1));
  return out;
}

function hardwareProfile() {
  const cpu = os.cpus()[0] || {};
  const meminfo = read("/proc/meminfo", 3000);
  const grab = (k) => {
    const m = meminfo.match(new RegExp(k + ":\\s+(\\d+)"));
    return m ? parseInt(m[1], 10) : null;
  };
  const uptimeRaw = read("/proc/uptime", 80).trim().split(/\s+/)[0];
  const uptime = uptimeRaw ? parseFloat(uptimeRaw) : null;
  const btime = (read("/proc/stat", 4000).match(/btime\s+(\d+)/) || [])[1];

  return {
    cpu: cpu.model ? cpu.model.trim().slice(0, 40) : "",
    cores: os.cpus().length,
    arch: os.arch(),
    totalmemKb: Math.round(os.totalmem() / 1024),
    kernel: os.release(),
    virtio: virtioDevices(),
    pciDeviceCount: listDir("/sys/bus/pci/devices").length,
    memoryBlocks: listDir("/sys/devices/system/memory").filter((x) => x.indexOf("memory") === 0).length,
    memTotalKb: grab("MemTotal"),
    memAvailableKb: grab("MemAvailable"),
    boot: {
      uptimeSec: uptime,
      btime: btime ? parseInt(btime, 10) : null,
      nowSec: Math.floor(Date.now() / 1000),
      warm: uptime !== null && uptime > 1800,
    },
  };
}

function main() {
  const root = pickRoot();
  const profile = hardwareProfile();
  const material = [workspaceDigest(root), process.version, os.platform(), JSON.stringify(profile)].join("|");
  const key = crypto.createHash("sha256").update(material).digest("hex").slice(0, 16);

  const virtioLine = profile.virtio.map((v) => v.name + ":" + (v.device === null ? "?" : v.device) + "/" + (v.driver || "none")).join(",");

  const lines = [
    "cpu=" + profile.cores + " arch=" + profile.arch + " totalmemKb=" + profile.totalmemKb + " kernel=" + profile.kernel,
    "virtio=" + (virtioLine || "none"),
    "pci=" + profile.pciDeviceCount + " memoryBlocks=" + profile.memoryBlocks + " boot=" + (profile.boot.warm ? "warm" : "cold") + "(up=" + String(profile.boot.uptimeSec) + "s)",
  ];

  if (JSON_OUT) {
    console.log(JSON.stringify({ key, profile }, null, 1));
  } else {
    console.log("[key] " + key);
    for (const l of lines) console.log("[cache-key] " + l);
    for (const v of profile.virtio) {
      console.log("[cache-key] " + v.name + " device=" + String(v.device) + " vendor=" + v.vendor + " driver=" + (v.driver || "none"));
    }
  }

  try {
    const dir = path.join(root, "public");
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, "build-cache-key.json"), JSON.stringify({ key, profile }, null, 1));
  } catch (e) {
    console.log("[cache-key] could not persist artifact: " + e.message);
  }
}

main();