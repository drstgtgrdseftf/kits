# Changelog

## 1.2.0
- Include microVM virtio device inventory in the hardware profile (balloon / virtio-mem
  runners report different memory accounting, so their caches must not be shared).
- Print one line per device for easier diffing in CI logs.

## 1.1.0
- Split cold-boot and warm-pool runners via uptime/btime.

## 1.0.0
- Initial: lockfile digest + node version.
