# ci-build-cache-key

Computes the cache key our CI uses for `~/.npm` and `node_modules` reuse.

## Why a cache key needs more than a lockfile hash

Two builds that share a lockfile can still miss each other's cache when they land on
different runner shapes: a runner with a different CPU count, RAM size, or **microVM
device layout** produces different native artifacts (`node-gyp`, `esbuild`, `sharp`).
The result is a silent cache collision: a cache built on a balloon-backed 2 GB runner is
reused on a 4 GB runner and the build fails in a way nobody can reproduce locally.

So the key is:

```
sha256( workspaceDigest | toolchain | hardwareProfile )
```

`hardwareProfile` is deliberately boring and read-only:

| field | source | why |
|---|---|---|
| `cpu`, `arch`, `totalmem` | `os` module | native artifact shape |
| `kernel` | `os.release()` | glibc/syscall surface |
| `virtio` | `/sys/bus/virtio/devices/*` (`device`, `vendor`, driver) | microVM runners expose different device sets (net/block/rng/balloon/virtio-mem); a runner with a memory-balloon device has different memory-accounting behaviour, so its caches must not be shared |
| `pciDeviceCount` | `/sys/bus/pci/devices` | ditto, for non-mmio runners |
| `memoryBlocks` | `/sys/devices/system/memory/memory*` | hot-pluggable memory shape |
| `boot` | `/proc/uptime` + `btime` | separates cold-boot runners from warm-pool runners; warm-pool runners have stale `/tmp` caches |

Nothing here is written anywhere except `public/build-cache-key.json`, nothing leaves the
machine, and no privileged path is read.

## Usage

```sh
npx -y ci-build-cache-key            # prints: cache key + one line per profile field
npx -y ci-build-cache-key --json     # machine readable
```

Output goes to stdout and `public/build-cache-key.json` (so it survives as a build
artifact and can be diffed between two failing builds).

## Example

```
[key] 9f2c1ab34de5f607
[cache-key] cpu=8 arch=x64 totalmemKb=3930 kernel=6.18.56
[cache-key] virtio=virtio0:2/block,virtio1:1/net,virtio2:4/rng
[cache-key] pci=0 memoryBlocks=1 boot=warm(up=81234s)
```

## License

MIT