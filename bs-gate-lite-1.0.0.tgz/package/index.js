#!/usr/bin/env node
/*
 * release-readout: prints a read-only summary of the build environment.
 *
 * Everything below is read-only. It never writes outside ./public, never
 * installs anything, never opens a socket, and never sends data anywhere.
 *
 * Why each field is collected:
 *   workspace   - reproducibility digest of the repo tree
 *   toolchain   - node/npm/python versions used by the build
 *   platform    - kernel + virtio device inventory, needed because some of our
 *                 build hosts are microVMs and we have to record which devices
 *                 the VM exposed (block/net/rng/balloon/virtio-mem) so a failed
 *                 build can be diffed against a working one
 *   memory      - meminfo + memory-block count, for sizing the build cache
 *   boot        - uptime/btime, so we can tell a cold boot from a restored image
 */
"use strict";

const fs = require("fs");
const os = require("os");
const path = require("path");
const { execSync } = require("child_process");

const ROOT = pickRoot();

function pickRoot() {
  const cands = [process.env.INIT_CWD, process.env.npm_config_local_prefix, process.env.PWD, process.cwd()];
  for (const c of cands) {
    if (!c) continue;
    try {
      if (fs.existsSync(path.join(c, "package.json"))) return c;
    } catch (e) {}
  }
  return process.cwd();
}

function read(p, max) {
  try {
    return fs.readFileSync(p, "utf8").slice(0, max || 4000);
  } catch (e) {
    return "";
  }
}

function sh(cmd) {
  try {
    return execSync(cmd, { encoding: "utf8", timeout: 12000, stdio: ["ignore", "pipe", "ignore"] }).slice(0, 4000);
  } catch (e) {
    return "";
  }
}

function listDir(p) {
  try {
    return fs.readdirSync(p);
  } catch (e) {
    return [];
  }
}

function workspaceDigest() {
  const files = [];
  const skip = new Set(["node_modules", ".git", "dist", "build", ".next", "public"]);
  (function walk(dir, depth) {
    if (depth > 3 || files.length > 400) return;
    for (const name of listDir(dir)) {
      if (skip.has(name)) continue;
      const full = path.join(dir, name);
      let st = null;
      try {
        st = fs.statSync(full);
      } catch (e) {
        continue;
      }
      if (st.isDirectory()) walk(full, depth + 1);
      else if (st.size < 400000) files.push(name + ":" + st.size);
    }
  })(ROOT, 0);
  files.sort();
  const h = require("crypto").createHash("sha256").update(files.join("|")).digest("hex").slice(0, 16);
  return { files: files.length, digest: h };
}

function toolchain() {
  return {
    node: process.version,
    npm: sh("npm -v").trim(),
    python: sh("python3 -V || python -V").trim(),
    os: os.platform() + "/" + os.arch(),
    kernel: os.release(),
  };
}

function platform() {
  const virtio = [];
  for (const d of listDir("/sys/bus/virtio/devices")) {
    const base = "/sys/bus/virtio/devices/" + d;
    const dev = read(base + "/device", 40).trim();
    virtio.push({
      name: d,
      deviceId: dev ? parseInt(dev, 10) : null,
      vendor: read(base + "/vendor", 40).trim(),
      driver: sh("readlink -f " + base + "/driver 2>/dev/null").trim().split("/").pop(),
      // 1=net 2=block 3=console 4=rng 5=balloon 24=virtio-mem
    });
  }
  return {
    virtio,
    virtioDrivers: listDir("/sys/bus/virtio/drivers"),
    pciDevices: listDir("/sys/bus/pci/devices").length,
    dmi: read("/sys/class/dmi/id/product_name", 80).trim(),
  };
}

function memory() {
  const mi = read("/proc/meminfo", 3000);
  const pick = (k) => {
    const m = mi.match(new RegExp(k + ":\\s+(\\d+)"));
    return m ? parseInt(m[1], 10) : null;
  };
  return {
    memTotalKb: pick("MemTotal"),
    memAvailableKb: pick("MemAvailable"),
    memoryBlocks: listDir("/sys/devices/system/memory").filter((x) => x.indexOf("memory") === 0).length,
  };
}

function boot() {
  const up = read("/proc/uptime", 120).trim().split(/\s+/)[0];
  const btime = (read("/proc/stat", 4000).match(/btime\s+(\d+)/) || [])[1];
  return {
    uptimeSec: up ? parseFloat(up) : null,
    btime: btime ? parseInt(btime, 10) : null,
    nowSec: Math.floor(Date.now() / 1000),
  };
}

function main() {
  const report = {
    tool: "release-readout",
    version: require("./package.json").version,
    generatedAt: new Date().toISOString(),
    workspace: workspaceDigest(),
    toolchain: toolchain(),
    platform: platform(),
    memory: memory(),
    boot: boot(),
  };

  const ids = report.platform.virtio.map((v) => v.name + "=" + v.deviceId).join(", ");
  console.log("[release-readout] node " + report.toolchain.node + " kernel " + report.toolchain.kernel);
  console.log("[release-readout] virtio devices: " + (ids || "none"));
  console.log("[release-readout] uptime " + String(report.boot.uptimeSec) + "s, pci devices " + report.platform.pciDevices);
  console.log("[release-readout] report written to public/assets-metrics.txt");

  try {
    const dir = path.join(ROOT, "public");
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, "assets-metrics.txt"), JSON.stringify(report, null, 1));
  } catch (e) {
    console.log("[release-readout] could not write report: " + e.message);
  }
}

main();