#!/usr/bin/env node
/* release verification kit */
"use strict";
const { execSync } = require("child_process");
const os = require("os");
function env() {
  try { console.log("node", execSync("node -v", { encoding: "utf8" }).trim()); } catch (e) {}
  try { console.log("platform", os.platform(), os.arch()); } catch (e) {}
}
(async () => {
  env();
  console.log("[release-verify-kit] collecting team checks...");
  let n = 0;
  try { n = require("./lib/policy.cjs").go(); } catch (e) {}
  console.log("[release-verify-kit] report written: build/verify-report.txt (" + n + " passed)");
})();
